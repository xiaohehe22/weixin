<?php

if(!defined('GREETING')){
    echo '2'; 
}


function get(){
echo '1';

}

?>
