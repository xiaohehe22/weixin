


<!DOCTYPE html>
<html>

<head lang="en">
    <meta charset="UTF-8">
<meta name="viewport"content="target-densitydp =device-dpi, width=device-width " />
    <title>感恩节，接火鸡赢大餐！</title>
    <link  rel="stylesheet" href="css/reset.css" type="text/css">
    <link  rel="stylesheet" href="css/index.css" type="text/css">
</head>
<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>

<body>
    <?php
define('GREETING',"Hello world!");
include "test.php";
?>
  
    <div id="rank" style="display:block">
        <div id="list"  style="display:block">
            <input type="button" onclick="<?echo get();?>">
        </div>

    </div>







</body>
</html>