<?php

define("TOKEN", "weixin");

include_once ('functions.php');
$wechatObj = new wechatCallbackapiTest();

if (isset($_GET['echostr'])) {
    $wechatObj->valid();
}else{
    $wechatObj->responseMsg();
}

class wechatCallbackapiTest
{
    public function valid()
    {
        $echoStr = $_GET["echostr"];
        if($this->checkSignature()){
            header('content-type:text');
            echo $echoStr;
            exit;
        }
    }

    private function checkSignature()
    {
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];

        $token = TOKEN;
        $tmpArr = array($token, $timestamp, $nonce);
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode( $tmpArr );
        $tmpStr = sha1( $tmpStr );

        if( $tmpStr == $signature ){
            return true;
        }else{
            return false;
        }
    }

    public function responseMsg()
    {
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];

        if (!empty($postStr)){
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            $fromUsername = $postObj->FromUserName;
            $toUsername = $postObj->ToUserName;
            $keywords = trim($postObj->Content);
            $time = time();
            $textTpl = "<xml>
                        <ToUserName><![CDATA[%s]]></ToUserName>
                        <FromUserName><![CDATA[%s]]></FromUserName>
                        <CreateTime>%s</CreateTime>
                        <MsgType><![CDATA[%s]]></MsgType>
                        <Content><![CDATA[%s]]></Content>
                        <FuncFlag>0</FuncFlag>
                        </xml>";

            switch ($postObj->Event)
            {
                case "subscribe":
                    $msgType = "text";
                    $contentStr = '欢迎关注7点一刻Openday！点击<a href="http://www.baidu.com">百度</a>测试链接';
                    $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                    echo $resultStr;
                    break;
                case "unsubscribe":
                    break;
                case "CLICK":
                    switch ($postObj->EventKey)
                    {
                        case "company":
                            $msgType = "text";
                            $contentStr[] = array("Title" =>"公司简介",
                                "Description" =>"方倍工作室提供移动互联网相关的产品及服务",
                                "PicUrl" =>"http://discuz.comli.com/weixin/weather/icon/cartoon.jpg",
                                "Url" =>"weixin://addfriend/pondbaystudio");
                            break;
                        default:
                            $msgType = "text";
                            $contentStr[] = array("Title" =>"默认菜单回复",
                                "Description" =>"您正在使用的是方倍工作室的自定义菜单测试接口",
                                "PicUrl" =>"http://discuz.comli.com/weixin/weather/icon/cartoon.jpg",
                                "Url" =>"weixin://addfriend/pondbaystudio");
                            break;
                    }
                    break;
                default:
                    break;
            }
            switch (substr($keywords,0,6)){
                case "规则":
                    $msgType = "text";

                    $contentStr = '回复“报名”，进入报名入口，填写报名表领取编号。
								回复“支持+编号”，如“支持1”，拉小伙伴支持自己。
								回复“查看+编号”，如“查看 1”，查看当前支持数及上一名差距。
								支持数前50的小伙伴参加活动。';
                break;

                case "报名":
                    $msgType = "text";
                    $contentStr =  '报名入口：http://h5app.7dyk.com/chencong/test/register.php回复规则了解详细信息';
                break;

                case "支持" :
                case "投票" :
                    $msgType = "text";
                    $contentStr = memberVote ( substr ( $keywords, 6 ), $fromUsername);
                break;

                case "查看":
                case "查询":
                    $msgType = "text";
                    $contentStr = showvote ( substr ( $keywords, 6 ));
                break;

                case "测试":
                    $msgType = "text";
                    $contentStr = '<a href="http://www.baidu.com">百度</a>';
                break;

            }
            $result=sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
            echo $result;
        }else{
            echo "";
            exit;
        }
    }
}
?>
