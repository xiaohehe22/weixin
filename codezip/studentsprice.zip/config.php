<?php
define("DB_HOST",SAE_MYSQL_HOST_M.":".SAE_MYSQL_PORT);
define("DB_USER",SAE_MYSQL_USER);
define("DB_PWD",SAE_MYSQL_PASS);
define("DB_DBNAME",SAE_MYSQL_DB);
define("DB_CHARSET","utf8");