<?php
/**
 * Created by PhpStorm.
 * User: CC
 * Date: 2016/8/4
 * Time: 14:45
 */

function db_connect(){
    $result = new mysqli('101.200.85.218', 'root','7DYKdev123!@#','test');
    if (!$result){
        echo 'Could not connect to database server';
    }else{

        return $result;
    }
}

function memberVote($memberid,$weixinid)
{
    $mysql = db_connect();

    $sql = "select id from test where id='$memberid'";
    $result = $mysql->query($sql);


    if($result==null){
        return  "好像没有这个id哦".$memberid;
    }


    $sql = "select id from vote where name='$weixinid'";
    $result = $mysql->query($sql);


    if($result!=null){
        return  "你已经给投过票啦";
    }else{
        $sql="insert into vote(name) values ($weixinid')";
        $mysql->query($sql);
    }


    $sql = "update test set vote = vote+1 where id='$memberid'";
    $mysql->query($sql);
    mysqli_close($mysql);
    return  "投票给".$memberid."成功,\n回复“查看+编号”，如“查看 1”，查看当前支持数及上一名差距";

}



function showVote($memberid)
{
    $mysql = db_connect();

    $sql = "select vote from test where id='$memberid'";
    //$sql = "select vote from user order by desc";
    $result = $mysql->query($sql);
    if($result==null){
        mysqli_close($mysql);
        return  "好像没有这个id哦".$memberid;
    }

    $test=$result->fetch_array();
    $vote=$test[0];

    $query= "select vote from test order by vote desc";
    $result=$mysql->query($query);
    //print_r($result);
    $test=$result->fetch_object();
    $pre=$test->id;

    for ($i=0;$row=$result->fetch_object();$i++){
        if($vote==$row->id) {
            $rank=$i+1;
            break;
        }
        $pre=$row->id;
    }
    $diff=$pre-$vote;

    mysqli_close($mysql);

    $result=$memberid."号当前票数为".$vote."，当前排名：第".$rank."名，距离上一名".$diff."票\n";

    return  $result;
}
