<?php
/*
    方倍工作室 http://www.cnblogs.com/txw1958/
    CopyRight 2013 www.fangbei.org  All Rights Reserved
*/
define("TOKEN", "weixin");

include_once ('functions.php');
$wechatObj = new wechatCallbackapiTest();

if (isset($_GET['echostr'])) {
    $wechatObj->valid();
}else{
    $wechatObj->responseMsg();
}

class wechatCallbackapiTest
{
    public function valid()
    {
        $echoStr = $_GET["echostr"];
        if($this->checkSignature()){
            header('content-type:text');
            echo $echoStr;
            exit;
        }
    }

    private function checkSignature()
    {
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];

        $token = TOKEN;
        $tmpArr = array($token, $timestamp, $nonce);
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode( $tmpArr );
        $tmpStr = sha1( $tmpStr );

        if( $tmpStr == $signature ){
            return true;
        }else{
            return false;
        }
    }

    public function responseMsg()
    {
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];

        if (!empty($postStr)){
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            $fromUsername = $postObj->FromUserName;
            $toUsername = $postObj->ToUserName;
            $keywords = trim($postObj->Content);
            $keyword=substr ( $keywords, 0, 6 );
            $time = time();
            $textTpl = "<xml>
                        <ToUserName><![CDATA[%s]]></ToUserName>
                        <FromUserName><![CDATA[%s]]></FromUserName>
                        <CreateTime>%s</CreateTime>
                        <MsgType><![CDATA[%s]]></MsgType>
                        <Content><![CDATA[%s]]></Content>
                        <FuncFlag>0</FuncFlag>
                        </xml>";
            $ev = $postObj->Event;
            if ($ev == "subscribe"){
  				$msgType = "text";
  				$contentStr = "欢迎关注7点一刻Openday！点击https://jinshuju.net/f/oVO4Y0直接报名京东OpenDAY活动，回复规则了解详细信息";
  				$resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
  				echo $resultStr;
			}


            if($keyword == "报名")
            {
                $msgType = "text";
                $contentStr =  '报名入口：http://7dyk.applinzi.com/register.php，回复规则了解详细信息';
                $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                echo $resultStr;
            }
            if($keyword == "规则")
            {
                $msgType = "text";
                
                $contentStr = '回复“报名”，进入报名入口，填写报名表领取编号。
								回复“支持+编号”，如“支持1”，拉小伙伴支持自己。
								回复“查看+编号”，如“查看 1”，查看当前支持数及上一名差距。
								支持数前50的小伙伴参加活动。
							   ';
                $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                echo $resultStr;
            }
            if($keyword == "京东")
            {
                $msgType = "text";
                
                $contentStr = '报名入口：https://jinshuju.net/f/oVO4Y0';
                $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                echo $resultStr;
            }
            if($keyword == "支持"||$keyword == "投票")
            {
                $msgType = "text";
                $contentStr = memberVote ( substr ( $keywords, 6 ), $fromUsername);
                $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                echo $resultStr;
            }
            if($keyword == "查看"||$keyword == "查询")
            {
                $msgType = "text";
                $contentStr = showvote ( substr ( $keywords, 6 ),  $fromUsername);
                $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                echo $resultStr;
            }
            
        }else{
            echo "";
            exit;
    }
    }
}
?>
